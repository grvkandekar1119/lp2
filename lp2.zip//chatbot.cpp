#include <iostream>
#include <string>
#include <algorithm>
using namespace std;

string getResponse(const string &message)
{
    string response;

    // Convert the message to lowercase
    string lowerMessage = message;
    transform(lowerMessage.begin(), lowerMessage.end(), lowerMessage.begin(), ::tolower);

    // Check for specific keywords in the message and generate appropriate responses
    if (lowerMessage.find("hello") != string::npos || lowerMessage.find("hi") != string::npos)
    {
        response = "Hello! How can I assist you?";
    }
    else if (lowerMessage.find("how are you") != string::npos)
    {
        response = "I'm a chat bot, so I don't have feelings, but thanks for asking!";
    }
    else if (lowerMessage.find("bye") != string::npos)
    {
        response = "Goodbye! Have a nice day!";
    }
    else
    {
        response = "I'm sorry, I didn't understand. Can you please rephrase?";
    }

    return response;
}

int main()
{
    cout << "Chat Bot: Hello! How can I assist you?" << std::endl;

    while (true)
    {
        string message;
        cout << "You: ";
        getline(cin, message);

        string response = getResponse(message);
        cout << "Chat Bot: " << response << endl;

        if (response == "Goodbye! Have a nice day!")
            break;
    }

    return 0;
}
