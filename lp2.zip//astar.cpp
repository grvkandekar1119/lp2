#include <iostream>
#include <vector>
#include <queue>
#include <cmath>
#include <algorithm>
#include <climits>

using namespace std;

typedef pair<int, int> pii;
typedef vector<vector<int>> Maze;

struct Node
{
    int row;
    int col;
    int g;
    int h;
    int f;
    Node(int r, int c, int gVal, int hVal) : row(r), col(c), g(gVal), h(hVal), f(gVal + hVal) {}
    bool operator<(const Node &other) const
    {
        return f > other.f;
    }
};

bool isValidCell(int row, int col, int numRows, int numCols)
{
    return (row >= 0 && row < numRows && col >= 0 && col < numCols);
}

int calculateHeuristic(int row, int col, int goalRow, int goalCol)
{
    return abs(row - goalRow) + abs(col - goalCol);
}

vector<pii> solveMaze(const Maze &maze, pii start, pii goal)
{
    int numRows = maze.size();
    int numCols = maze[0].size();

    vector<int> dRow = {-1, 1, 0, 0};
    vector<int> dCol = {0, 0, -1, 1};

    priority_queue<Node> pq;
    pq.push(Node(start.first, start.second, 0, calculateHeuristic(start.first, start.second, goal.first, goal.second)));

    vector<vector<bool>> visited(numRows, vector<bool>(numCols, false));
    vector<vector<pii>> parent(numRows, vector<pii>(numCols, make_pair(-1, -1)));
    vector<vector<int>> distance(numRows, vector<int>(numCols, INT_MAX));

    while (!pq.empty())
    {
        Node current = pq.top();
        pq.pop();

        int row = current.row;
        int col = current.col;

        if (row == goal.first && col == goal.second)
        {
            vector<pii> path;
            while (row != -1 && col != -1)
            {
                path.push_back(make_pair(row, col));
                int newRow = parent[row][col].first;
                int newCol = parent[row][col].second;
                row = newRow;
                col = newCol;
            }
            reverse(path.begin(), path.end());
            return path;
        }

        visited[row][col] = true;

        for (int i = 0; i < 4; ++i)
        {
            int newRow = row + dRow[i];
            int newCol = col + dCol[i];

            if (isValidCell(newRow, newCol, numRows, numCols) && maze[newRow][newCol] != 1 && !visited[newRow][newCol])
            {
                int newG = current.g + 1;
                int newH = calculateHeuristic(newRow, newCol, goal.first, goal.second);
                int newF = newG + newH;

                if (newF < current.f || parent[newRow][newCol] == make_pair(-1, -1))
                {
                    parent[newRow][newCol] = make_pair(row, col);
                    distance[newRow][newCol] = newG;
                    pq.push(Node(newRow, newCol, newG, newH));
                }
            }
        }
    }

    return vector<pii>();
}

void printMaze(const Maze &maze)
{
    for (const auto &row : maze)
    {
        for (int cell : row)
        {
            cout << cell << " ";
        }
        cout << endl;
    }
}

int main()
{
    Maze maze = {
        {0, 1, 0, 0, 0},
        {0, 1, 1, 1, 0},
        {0, 0, 1, 1, 0},
        {0, 1, 0, 1, 0},
        {0, 0, 0, 1, 1},
    };

    pii start = make_pair(0, 0);
    pii goal = make_pair(4, 4);

    vector<pii> path = solveMaze(maze, start, goal);

    if (path.empty())
    {
        cout << "No path found!" << endl;
    }
    else
    {
        cout << "Path found:" << endl;
        for (const auto &cell : path)
        {
            cout << "(" << cell.first << ", " << cell.second << ")" << endl;
        }
    }

    return 0;
}
